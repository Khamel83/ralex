#!/bin/bash

echo "RalexOS Installer"
echo "================"

# Make the main script executable
chmod +x ralexos-complete.sh

# Show installation instructions
echo "Setup files copied to current directory."
echo "To install RalexOS:"
echo "1. Edit ralexos-complete.sh and set your configuration values"
echo "2. Run: ./ralexos-complete.sh"
echo "3. Follow the on-screen instructions"

echo
echo "For detailed instructions, see INSTALL.md"
echo "For full documentation, see README.md"
