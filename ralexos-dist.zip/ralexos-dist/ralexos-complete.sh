#!/bin/bash

# RalexOS - Complete OpenCode Setup
# Single script to set up your OpenCode environment with MCP on any platform

set -euo pipefail

# Configuration - EDIT THESE VALUES FOR YOUR SETUP
OPENROUTER_API_KEY="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"
GITHUB_TOKEN=""
GIT_USER_NAME="Your Name"
GIT_USER_EMAIL="your.email@example.com"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log() { echo -e "${NC}[INFO] $*${NC}"; }
success() { echo -e "${GREEN}[SUCCESS] $*${NC}"; }
warn() { echo -e "${YELLOW}[WARNING] $*${NC}"; }
error() { echo -e "${RED}[ERROR] $*${NC}"; }
highlight() { echo -e "${BLUE}[ACTION] $*${NC}"; }

# Platform detection
detect_platform() {
    case "$(uname -s)" in
        Darwin*) echo "macos" ;;
        Linux*)
            if [[ -f /etc/os-release ]]; then
                if grep -qi "ubuntu\|debian" /etc/os-release; then
                    echo "ubuntu"
                else
                    echo "linux"
                fi
            else
                echo "linux"
            fi
            ;;
        *) echo "unknown" ;;
    esac
}

PLATFORM=$(detect_platform)
log "Detected platform: $PLATFORM"

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Install system dependencies
install_system_deps() {
    case "$PLATFORM" in
        macos)
            if ! command_exists brew; then
                highlight "Installing Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            brew update
            brew install node git curl || true
            ;;
        ubuntu)
            highlight "Installing system dependencies..."
            sudo apt update
            sudo apt install -y curl git build-essential ca-certificates
            sudo apt install -y nodejs npm || true
            ;;
        linux)
            log "Please ensure you have curl, git, and nodejs installed"
            ;;
    esac
}

# Install Bun
install_bun() {
    if ! command_exists bun; then
        highlight "Installing Bun..."
        curl -fsSL https://bun.sh/install | bash
        export BUN_INSTALL="$HOME/.bun"
        export PATH="$BUN_INSTALL/bin:$PATH"
        
        # Add to shell profile
        local profile_files=("$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile")
        for profile in "${profile_files[@]}"; do
            if [[ -f "$profile" ]]; then
                if ! grep -q "BUN_INSTALL" "$profile" 2>/dev/null; then
                    echo 'export BUN_INSTALL="$HOME/.bun"' >> "$profile"
                    echo 'export PATH="$BUN_INSTALL/bin:$PATH"' >> "$profile"
                fi
            fi
        done
    fi
    success "Bun ready"
}

# Install OpenCode
install_opencode() {
    if ! command_exists opencode; then
        highlight "Installing OpenCode..."
        case "$PLATFORM" in
            macos)
                brew install sst/tap/opencode || true
                ;;
            *)
                curl -fsSL https://opencode.ai/install | bash
                ;;
        esac
    fi
    
    if command_exists opencode; then
        success "OpenCode installed"
    else
        error "Failed to install OpenCode. Please install manually:"
        log "curl -fsSL https://opencode.ai/install | bash"
        return 1
    fi
}

# Install MCP servers
install_mcp_servers() {
    highlight "Installing MCP servers..."
    
    # Ensure npm is available
    if ! command_exists npm; then
        error "npm is required but not found"
        return 1
    fi
    
    # MCP servers to install
    local mcp_servers=(
        "@upstash/context7-mcp"
        "@github/github-mcp-server"
        "@modelcontextprotocol/server-puppeteer"
        "@arben-adm/mcp-sequential-thinking"
        "zen-mcp-server"
        "memory-bank-mcp"
    )
    
    # Install each MCP server
    for server in "${mcp_servers[@]}"; do
        log "Installing $server..."
        if npm install -g "$server" >/dev/null 2>&1; then
            success "Installed $server"
        else
            warn "Failed to install $server"
        fi
    done
}

# Set up Git identity
setup_git() {
    highlight "Setting up Git identity..."
    git config --global user.name "$GIT_USER_NAME"
    git config --global user.email "$GIT_USER_EMAIL"
    success "Git identity set"
}

# Generate SSH key
generate_ssh_key() {
    local ssh_dir="$HOME/.ssh"
    local key_file="$ssh_dir/id_ed25519"
    
    mkdir -p "$ssh_dir"
    chmod 700 "$ssh_dir"
    
    if [[ ! -f "$key_file" ]]; then
        highlight "Generating SSH key..."
        ssh-keygen -t ed25519 -N "" -C "$GIT_USER_EMAIL" -f "$key_file" >/dev/null
        eval "$(ssh-agent -s)" >/dev/null 2>&1 || true
        ssh-add "$key_file" >/dev/null 2>&1 || true
        success "SSH key generated"
    else
        success "SSH key already exists"
    fi
}

# Create OpenCode configuration
create_opencode_config() {
    local config_dir="$HOME/.config/opencode"
    local config_file="$config_dir/opencode.json"
    
    highlight "Creating OpenCode configuration..."
    
    # Create config directory
    mkdir -p "$config_dir"
    
    # Create configuration with MCP servers
    cat > "$config_file" << EOF
{
  "\$schema": "https://opencode.ai/config.json",
  "model": "anthropic/claude-sonnet-4-20250514",
  "small_model": "openrouter/qwen/qwen3-coder:free",
  "provider": {
    "openrouter": {
      "options": {
        "headers": {
          "HTTP-Referer": "https://github.com/ralexos",
          "X-Title": "RalexOS"
        }
      },
      "models": {
        "moonshotai/kimi-k2:free": {},
        "qwen/qwen3-coder:free": {},
        "google/gemini-2.0-flash-001": {},
        "deepseek/deepseek-r1-0528:free": {}
      }
    }
  },
  "agent": {
    "claude-pro": {
      "description": "Claude Sonnet via Pro/Max (OAuth)",
      "model": "anthropic/claude-sonnet-4-20250514"
    },
    "kimi-free": {
      "description": "Kimi K2 (free) via OpenRouter",
      "model": "openrouter/moonshotai/kimi-k2:free"
    },
    "qwen3-free": {
      "description": "Qwen3 Coder (free) via OpenRouter",
      "model": "openrouter/qwen/qwen3-coder:free"
    },
    "gemini-flash": {
      "description": "Gemini 2.0 Flash via OpenRouter",
      "model": "openrouter/google/gemini-2.0-flash-001"
    },
    "yolo": {
      "description": "Apply diffs immediately; avoid confirmations; minimize chatter.",
      "system": "You are in YOLO mode. Make intelligent assumptions, ask only when blocking, apply diffs immediately without confirmation, summarize briefly, and proceed."
    }
  },
  "mcp": {
    "servers": {
      "context7": {
        "type": "local",
        "command": "context7-mcp"
      },
      "github": {
        "type": "local",
        "command": "github-mcp-server",
        "args": ["stdio"]
      },
      "puppeteer": {
        "type": "local",
        "command": "server-puppeteer"
      },
      "sequential": {
        "type": "local",
        "command": "mcp-sequential-thinking"
      },
      "zen": {
        "type": "local",
        "command": "zen-mcp-server"
      },
      "memorybank": {
        "type": "local",
        "command": "memory-bank-mcp"
      }
    }
  },
  "share": "manual"
}
EOF
    
    success "OpenCode configuration created at $config_file"
}

# Set up environment variables
setup_env_vars() {
    highlight "Setting up environment variables..."
    
    # Environment variables to export
    local env_vars=(
        "OPENROUTER_API_KEY=$OPENROUTER_API_KEY"
    )
    
    # Add to shell profiles
    local profile_files=("$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile")
    for profile in "${profile_files[@]}"; do
        if [[ -f "$profile" ]]; then
            for var in "${env_vars[@]}"; do
                if ! grep -q "${var%%=*}=" "$profile" 2>/dev/null; then
                    echo "export $var" >> "$profile"
                fi
            done
        fi
    done
    
    # Export for current session
    for var in "${env_vars[@]}"; do
        export "$var"
    done
    
    success "Environment variables set"
}

# Create helper aliases
create_aliases() {
    highlight "Creating helper aliases..."
    
    local aliases_content='
# RalexOS/OpenCode helpers
alias opencode="command opencode"
alias ocp="command opencode -m anthropic/claude-sonnet-4-20250514"
alias ocq="command opencode -m openrouter/qwen/qwen3-coder:free"
alias ocg="command opencode -m openrouter/google/gemini-2.0-flash-001"
alias ock="command opencode -m openrouter/moonshotai/kimi-k2:free"
oy() { command opencode run "$@"; }
'

    # Add to shell profiles
    local profile_files=("$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile")
    for profile in "${profile_files[@]}"; do
        if [[ -f "$profile" ]]; then
            if ! grep -q "# RalexOS/OpenCode helpers" "$profile" 2>/dev/null; then
                echo "$aliases_content" >> "$profile"
            fi
        fi
    done
    
    success "Helper aliases created"
}

# Verify installation
verify_installation() {
    highlight "Verifying installation..."
    
    # Check if required commands exist
    local required_commands=("opencode" "bun" "node" "npm")
    for cmd in "${required_commands[@]}"; do
        if command_exists "$cmd"; then
            success "Found $cmd"
        else
            warn "Missing $cmd"
        fi
    done
    
    # Check MCP servers
    local mcp_servers=("context7-mcp" "github-mcp-server" "server-puppeteer" 
                       "mcp-sequential-thinking" "zen-mcp-server" "memory-bank-mcp")
    for server in "${mcp_servers[@]}"; do
        if command_exists "$server"; then
            success "Found MCP server: $server"
        else
            warn "Missing MCP server: $server"
        fi
    done
    
    # Check configuration
    local config_file="$HOME/.config/opencode/opencode.json"
    if [[ -f "$config_file" ]]; then
        success "Configuration file exists"
    else
        warn "Configuration file missing"
    fi
}

# Show usage instructions
show_usage() {
    echo
    highlight "Setup complete! To get started:"
    echo
    log "1. Restart your shell or run: source ~/.bashrc (or ~/.zshrc)"
    log "2. Use these commands:"
    echo "   - opencode        : Start OpenCode TUI"
    echo "   - ocp             : Force Claude Pro model"
    echo "   - ocq             : Use Qwen3 Coder (free)"
    echo "   - ocg             : Use Gemini Flash"
    echo "   - ock             : Use Kimi K2 (free)"
    echo "   - oy \"command\"    : Run one-shot command"
    echo
    log "In OpenCode TUI, you can use these special commands:"
    echo "   - @yolo <task>    : Run in YOLO mode (no confirmations)"
    echo "   - /mcp            : Manage MCP servers"
    echo "   - /models         : Switch between models"
    echo
    log "MCP servers included:"
    echo "   - Context7        : Context management"
    echo "   - GitHub          : GitHub integration"
    echo "   - Puppeteer       : Web browsing"
    echo "   - Sequential      : Sequential thinking"
    echo "   - Zen             : General tools"
    echo "   - MemoryBank      : Memory management"
    echo
}

# Main installation function
main() {
    log "Starting RalexOS setup..."
    
    # Check if we're running interactively
    if [[ $- == *i* ]]; then
        log "Running in interactive mode"
    else
        log "Running in non-interactive mode"
    fi
    
    # Install dependencies
    install_system_deps
    install_bun
    install_opencode
    
    # Set up Git and SSH
    setup_git
    generate_ssh_key
    
    # Install and configure MCP
    install_mcp_servers
    create_opencode_config
    setup_env_vars
    create_aliases
    
    # Verify and show usage
    verify_installation
    show_usage
    
    success "RalexOS setup complete!"
    log "Enjoy your AI-powered development environment!"
}

# Run main function if script is executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi