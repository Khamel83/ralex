# RalexOS Distribution Package

This package contains everything you need to set up RalexOS on any machine.

## Contents

1. `ralexos-complete.sh` - The main setup script
2. `README.md` - Full documentation
3. `INSTALL.md` - Quick installation guide
4. `demo.sh` - Demonstration script
5. `install.sh` - Simple installer

## Installation

1. Extract this package to a directory
2. Edit `ralexos-complete.sh` to set your configuration values:
   - OPENROUTER_API_KEY
   - GITHUB_TOKEN
   - GIT_USER_NAME
   - GIT_USER_EMAIL
3. Run the setup: `./ralexos-complete.sh`
4. Follow the on-screen instructions

## Platform Support

This package works on:
- macOS (Intel and Apple Silicon)
- Ubuntu/Debian
- Other Linux distributions
- Raspberry Pi
- VPS servers

## Getting Started

After installation:
1. Restart your shell or source your profile
2. Run `opencode` to start the AI assistant
3. Try the aliases: `ocp`, `ocq`, `ocg`, `ock`, `oy`

## Documentation

See README.md for complete documentation and usage instructions.
